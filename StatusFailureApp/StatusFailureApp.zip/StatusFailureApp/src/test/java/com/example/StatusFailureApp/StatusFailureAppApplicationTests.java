package com.example.StatusFailureApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatusFailureAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
